xcopy /d /i /s /c /y "T:\T_Drive\tCode\libraries\TeensyUserInterfaceST" . 

Pause